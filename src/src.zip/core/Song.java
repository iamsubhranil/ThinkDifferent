/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.io.Serializable;

/**
 *
 * @author Subhra
 */
public class Song implements Serializable{
    private static final long serialVersionUID = 3403340764899391441L;
    
    private final String path;
    
    private final String title;
    
    private final String artist;
    
    private final String album;

    public Song(String path, String title, String artist, String album) {
        this.path = path;
        this.title = title;
        this.artist = artist;
        this.album = album;
    }

    public String getPath() {
        return path;
    }

    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }

    public String getAlbum() {
        return album;
    }
    
    
    
}
